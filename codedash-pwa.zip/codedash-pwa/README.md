# CodeDash PWA 📱

## Installer sur iPhone (iOS Safari)

### Option A — GitHub Pages (GRATUIT, recommandé)

1. Va sur **github.com** → crée un compte gratuit
2. Clique **"New repository"** → nomme-le `codedash`
3. Upload tous les fichiers de ce dossier
4. Va dans **Settings → Pages → Branch: main → Save**
5. Ton URL sera : `https://TON_NOM.github.io/codedash`
6. **Ouvre cette URL sur Safari iPhone**
7. Bouton Partager (□↑) → **"Sur l'écran d'accueil"**
8. ✅ CodeDash est installé comme une vraie app !

---

### Option B — Netlify Drop (le plus rapide, 30 secondes)

1. Va sur **netlify.com/drop**
2. Glisse-dépose tout le dossier `codedash-pwa`
3. Tu reçois une URL gratuite type `https://xxxx.netlify.app`
4. Ouvre sur Safari iPhone → Partager → Sur l'écran d'accueil

---

### Pourquoi Safari et pas Chrome sur iPhone ?

Apple oblige tous les navigateurs iOS à utiliser le moteur Safari.
L'installation PWA ne fonctionne qu'avec **Safari** sur iPhone.

---

## Structure des fichiers

```
codedash-pwa/
├── index.html      ← Le jeu complet
├── manifest.json   ← Config PWA (nom, couleurs, icônes)
├── sw.js           ← Service Worker (mode hors-ligne)
├── favicon.ico     ← Favicon navigateur
└── icons/          ← Icônes toutes tailles (iOS + Android)
    ├── icon-180x180.png   ← iPhone (apple-touch-icon)
    ├── icon-192x192.png   ← Android
    ├── icon-512x512.png   ← Android splash
    └── ...
```

## Version
CodeDash v1.0.0 — Made by Anir · Help of Claude AI
Beta testers : Aya, Chaimae (@fire-chouchou)
